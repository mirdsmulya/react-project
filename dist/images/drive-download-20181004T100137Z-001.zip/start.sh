echo "******************** Starting ********************"
python script.py
. shell.sh
python main.py
python delete.py
