import os

print "Deleting Cache"
os.system('rm ip.txt')
os.system('rm nova.txt')
os.system('rm merge.txt')
os.system('rm id.txt')
os.system('rm collect_ipmi.sh')
os.system('rm merge.sh')
os.system('rm collect_id.sh')
os.system('rm list_server.txt')
os.system('rm result.txt')
#os.system('rm final_result.txt')
os.system('rm uuid.txt')
